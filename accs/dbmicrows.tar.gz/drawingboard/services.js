'use strict';

/* Services */

var myModule = angular.module('myApp.services', ['ngResource']);
